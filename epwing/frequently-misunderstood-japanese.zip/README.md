Frequently Misunderstood Japanese: A Handy Guide For Translators
================================================================

Adapted the guide in a form friendly for use with [yomichan](https://foosoft.net/projects/yomichan/) and software that can read yomichan dictionary format (e.g. [Didactical Enigma](https://github.com/DidacticalEnigma/DidacticalEnigma))

How to use
-----------

Place the .json files in a .zip file. Files must be in root directory, which is why "Download ZIP" option won't work.

Source
------

https://twitter.com/zoid9000/status/1397283834199265282

https://drive.google.com/file/d/1M6-VKPvPYVeI_VYrX_xdcDsoifqkosW2/view